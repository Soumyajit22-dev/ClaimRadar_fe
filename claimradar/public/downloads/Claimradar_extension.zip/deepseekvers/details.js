// details.js - Fixed version with proper layout and backend handling

document.addEventListener('DOMContentLoaded', function() {
    console.log('📄 Details page loaded');
    
    // Back button
    document.getElementById('backButton').addEventListener('click', function() {
        window.close();
    });

    // Refresh button
    document.getElementById('refreshButton').addEventListener('click', function() {
        location.reload();
    });

    // Add clear cache button
    const clearCacheBtn = document.createElement('button');
    clearCacheBtn.textContent = '🗑️ Clear Cache';
    clearCacheBtn.style.cssText = `
        position: fixed;
        top: 10px;
        right: 10px;
        background: #ec1313;
        color: white;
        border: none;
        padding: 8px 16px;
        border-radius: 4px;
        cursor: pointer;
        font-size: 12px;
    `;
    clearCacheBtn.addEventListener('click', async function() {
        await new Promise((resolve) => {
            chrome.storage.local.remove(['collectedData', 'currentAnalysis', 'lastAnalysisUrl', 'lastScanTime', 'flaggedCount', 'analysisHistory'], resolve);
        });
        location.reload();
    });
    document.body.appendChild(clearCacheBtn);

    // Load data immediately
    loadAnalysisData();
});

function loadAnalysisData() {
    console.log('🔍 Loading analysis data...');
    
    chrome.storage.local.get(['collectedData', 'currentAnalysis', 'analysisHistory'], function(data) {
        console.log('📦 Retrieved from storage:', {
            hasCollectedData: !!data.collectedData,
            hasCurrentAnalysis: !!data.currentAnalysis,
            historyLength: Array.isArray(data.analysisHistory) ? data.analysisHistory.length : 0
        });
        
        if (data.collectedData || data.currentAnalysis) {
            // Show data sections
            document.getElementById('noDataMessage').style.display = 'none';
            document.getElementById('dataSection').style.display = 'block';
            document.getElementById('analysisContent').style.display = 'block';
            
            // Display analysis results with collected data appended at bottom
            showAnalysisResults(data.currentAnalysis, data.collectedData, data.analysisHistory || []);
            
        } else {
            // No data found
            console.log('❌ No data found in storage');
            document.getElementById('noDataMessage').style.display = 'block';
            document.getElementById('dataSection').style.display = 'none';
            document.getElementById('analysisContent').style.display = 'none';
        }
    });
}

function showCollectedData(collectedData) {
    console.log('📊 Displaying collected data');
    
    const dataContent = document.getElementById('dataContent');
    
    if (!collectedData) {
        dataContent.innerHTML = '<p style="color: #888; text-align: center;">No data collected</p>';
        return;
    }

    // Extract values safely
    const textLength = collectedData.content?.text?.length || 0;
    const wordCount = collectedData.content?.text ? 
        collectedData.content.text.split(/\s+/).length : 0;
    const contentType = (collectedData.content?.content_type || 'unknown').toUpperCase();
    const domain = collectedData.context?.domain || 'Unknown';

    // Compact data cards
    const statsHtml = `
        <div style="display: flex; justify-content: space-around; background: #2a2a2a; padding: 12px; border-radius: 8px; margin-bottom: 15px; font-size: 12px;">
            <div style="text-align: center;">
                <div style="color: #888; font-size: 11px; margin-bottom: 4px;">TEXT</div>
                <div style="font-weight: 600; color: #e0e0e0;">${wordCount} words</div>
            </div>
            <div style="text-align: center;">
                <div style="color: #888; font-size: 11px; margin-bottom: 4px;">TYPE</div>
                <div style="font-weight: 600; color: #e0e0e0;">${contentType}</div>
            </div>
            <div style="text-align: center;">
                <div style="color: #888; font-size: 11px; margin-bottom: 4px;">DOMAIN</div>
                <div style="font-weight: 600; color: #e0e0e0; font-size: 11px; word-break: break-all;">${domain}</div>
            </div>
        </div>
    `;

    // JSON viewer for collected data
    const jsonViewer = `
        <details style="margin-top: 10px;">
            <summary style="cursor: pointer; color: #888; font-weight: 600; padding: 8px; background: #2a2a2a; border-radius: 4px; user-select: none; font-size: 12px;">
                📋 View Collected Data JSON (Click to expand)
            </summary>
            <div class="json-viewer">
                <pre style="font-size: 11px;">${JSON.stringify(collectedData, null, 2)}</pre>
            </div>
        </details>
    `;

    dataContent.innerHTML = statsHtml + jsonViewer;
}

// NEW: Show backend received data
function showBackendReceivedData(analysisData, analysisHistory = []) {
    console.log('📊 Displaying backend received data');
    
    // Get the backend raw result if it exists
    const backendData = analysisData?.backend_raw_result;

    if (!backendData) {
        return '<p style="color: #888; text-align: center;">No backend data received</p>';
    }

    // Ensure sources is shown even if backend returned a string or a single message
    const normalizedSources = (() => {
        const s = backendData.sources;
        if (!s) return [];
        if (Array.isArray(s)) return s;
        if (typeof s === 'string') return [s];
        try {
            return Array.from(s);
        } catch (e) {
            return [];
        }
    })();

    // Build a small header that shows the raw confidence/sensitivity if present
    const rawConfidence = backendData.confidence_score !== undefined ? backendData.confidence_score : 'N/A';
    const rawCorrectness = backendData.Correctness !== undefined ? backendData.Correctness : (backendData.correctness !== undefined ? backendData.correctness : 'N/A');

    // Show the most recent audit entry (if any) so the user can compare with Postman
    let lastAuditHtml = '';
    try {
        const lastEntry = analysisHistory && analysisHistory.length ? analysisHistory[analysisHistory.length - 1] : null;
        if (lastEntry) {
            lastAuditHtml = `
                <details style="margin-top: 6px; border: 1px dashed #444; padding:8px; border-radius:6px;">
                    <summary style="cursor: pointer; color: #f59e0b; font-weight: 600; user-select: none;">🧾 Latest Audit Entry (Click to expand)</summary>
                    <div style="margin-top:8px; font-size:12px; color:#ccc;">
                        <div><strong>Timestamp:</strong> ${lastEntry.timestamp}</div>
                        <div style="margin-top:6px;"><strong>Request URL:</strong> ${lastEntry.requestUrl}</div>
                        <div style="margin-top:6px;"><strong>Payload Sent:</strong>
                            <pre style="font-size:11px; max-height:200px; overflow:auto; background:#111; padding:8px; border-radius:4px;">${JSON.stringify(lastEntry.payloadSent, null, 2)}</pre>
                        </div>
                        <div style="margin-top:6px;"><strong>Response Status:</strong> ${lastEntry.responseStatus}</div>
                        <div style="margin-top:6px;"><strong>Response Headers:</strong>
                            <pre style="font-size:11px; max-height:180px; overflow:auto; background:#111; padding:8px; border-radius:4px;">${JSON.stringify(lastEntry.responseHeaders || {}, null, 2)}</pre>
                        </div>
                        <div style="margin-top:6px;"><strong>Response Body:</strong>
                            <pre style="font-size:11px; max-height:300px; overflow:auto; background:#111; padding:8px; border-radius:4px;">${typeof lastEntry.responseReceived === 'string' ? lastEntry.responseReceived : JSON.stringify(lastEntry.responseReceived, null, 2)}</pre>
                        </div>
                    </div>
                </details>
            `;
        }
    } catch (e) {
        console.warn('Failed to render last audit entry', e);
    }

    // Show backend JSON plus a short summary and the raw payload/sensitivity if available
    const backendJsonViewer = `
        <div style="font-size:12px; color:#888; margin-bottom:8px;">Raw confidence: <strong style="color:#e0e0e0;">${rawConfidence}</strong> · Correctness: <strong style="color:#e0e0e0;">${rawCorrectness}</strong></div>
        ${lastAuditHtml}
        <details style="margin-top: 6px;">
            <summary style="cursor: pointer; color: #2563eb; font-weight: 600; padding: 8px; background: #1a2a2a; border-radius: 4px; user-select: none; font-size: 12px; border: 1px solid #2563eb;">
                🔬 View Backend Response JSON (Click to expand)
            </summary>
            <div class="json-viewer" style="margin-top:8px;">
                <pre style="font-size: 11px;">${JSON.stringify(backendData, null, 2)}</pre>
            </div>
        </details>
        ${normalizedSources.length > 0 ? `
            <div style="margin-top:10px; font-size:12px; color:#e0e0e0;">
                <div style="color:#888; font-size:11px; margin-bottom:6px;">Verification sources / notes from backend:</div>
                <ul style="color:#ccc; font-size:12px; padding-left:18px;">
                    ${normalizedSources.map(src => `<li style="margin-bottom:6px; word-break:break-word;">${src}</li>`).join('')}
                </ul>
            </div>
        ` : ''}
    `;

    return backendJsonViewer;
}

function showAnalysisResults(analysisData, collectedData, analysisHistory = []) {
    console.log('🔍 Displaying analysis results');
    
    const analysisContent = document.getElementById('analysisContent');
    
    if (!analysisData) {
        analysisContent.innerHTML = `
            <div class="real-info">
                <p style="color: #888;">⚠️ No analysis results available yet.</p>
                <p style="color: #888; margin-top: 10px;">The page data has been collected. Analysis will appear here once processing is complete.</p>
            </div>
        `;
        return;
    }

    let html = '';

    // Prefer to show the exact payload sent to the backend (if saved) instead of raw collectedData JSON
    const payloadToShow = analysisData?.backend_payload_sent || collectedData;
    // MAIN VERDICT - At the very top as requested
    const isMisleading = analysisData.is_misleading;
    
    // Get confidence from analysisData or from backend_raw_result
    let confidence = analysisData.confidence_score;
    if (confidence === undefined || confidence === null) {
        // Try to get from backend
        const backend = analysisData.backend_raw_result;
        if (backend && backend.confidence_score !== undefined) {
            confidence = typeof backend.confidence_score === 'string' 
                ? parseFloat(backend.confidence_score) 
                : backend.confidence_score;
        }
    }
    const confidencePercent = (confidence !== undefined && confidence !== null)
        ? (parseFloat(confidence) * 100).toFixed(0)
        : 'N/A';
    const statusColor = isMisleading ? '#ec1313' : '#10b981';
    const statusText = isMisleading ? 'Potentially Misleading Content' : 'Appears Credible';
    const statusIcon = isMisleading ? '⚠️' : '✅';
    const statusDescription = isMisleading 
        ? 'This content may contain misinformation' 
        : 'This content appears to be credible';

    html += `
        <div style="background: linear-gradient(135deg, ${isMisleading ? 'rgba(236, 19, 19, 0.1)' : 'rgba(16, 185, 129, 0.1)'} 0%, 
                    ${isMisleading ? 'rgba(220, 18, 18, 0.15)' : 'rgba(14, 165, 119, 0.15)'} 100%); 
                    padding: 30px; 
                    border-radius: 16px; 
                    border: 2px solid ${statusColor};
                    margin-bottom: 25px;
                    text-align: center;
                    box-shadow: 0 8px 30px ${isMisleading ? 'rgba(236, 19, 19, 0.3)' : 'rgba(16, 185, 129, 0.3)'};
                    backdrop-filter: blur(10px);
                    animation: slideIn 0.5s ease-out;">
            <div style="font-size: 48px; margin-bottom: 15px; filter: drop-shadow(0 4px 8px rgba(0,0,0,0.3));">${statusIcon}</div>
            <div style="font-size: 28px; font-weight: 700; color: ${statusColor}; margin-bottom: 12px; letter-spacing: 0.5px;">
                ${statusText}
            </div>
            <div style="color: #e0e0e0; font-size: 15px; margin-bottom: 15px; max-width: 600px; margin-left: auto; margin-right: auto;">
                ${statusDescription}
            </div>
            <div style="color: #888; font-size: 14px;">
                AI Confidence: <strong style="color: ${statusColor}; font-size: 18px; font-weight: 700;">${confidencePercent}%</strong>
            </div>
        </div>
    `;

    // Source info - below the verdict
    const url = analysisData.url || collectedData?.content?.url || 'Unknown URL';
    const title = analysisData.title || collectedData?.content?.title || 'Untitled Page';
    const scannedAt = analysisData.scannedAt ? 
        new Date(analysisData.scannedAt).toLocaleString() : 'Recently';
    
    // Add cache warning if data is older than 5 minutes
    const isOldCache = analysisData.scannedAt && 
        (new Date().getTime() - new Date(analysisData.scannedAt).getTime()) > 5 * 60 * 1000;
    
    html += `
        <div style="background: #2a2a2a; padding: 12px; border-radius: 6px; margin-bottom: 15px;">
            <div style="color: #2563eb; font-size: 14px; font-weight: 600; margin-bottom: 4px;">${title}</div>
            <div style="color: #888; font-size: 10px; word-break: break-all; margin-bottom: 4px;">${url}</div>
            <div style="color: ${isOldCache ? '#ec1313' : '#666'}; font-size: ${isOldCache ? '12px' : '9px'}; display: flex; align-items: center; gap: 4px;">
                ${isOldCache ? '⚠️' : '🕒'} ${isOldCache ? 'CACHED DATA from:' : 'Scanned:'} ${scannedAt}
                ${isOldCache ? '<span style="color: #888; font-size: 10px;"> (Click Scan to refresh)</span>' : ''}
            </div>
        </div>
    `;

    // FIRST: Show backend AI analysis results prominently (after verdict)
    // Only show if we have actual backend data (not error state)
    if (analysisData.backend_raw_result && !analysisData.error) {
        html += showBackendAnalysis(analysisData);
    } else if (analysisData.error) {
        // Show error message prominently
        html += `
            <div style="background: #2a1a1a; padding: 20px; border-radius: 10px; border: 2px solid #ec1313; margin-bottom: 20px;">
                <div style="font-size: 28px; margin-bottom: 15px; text-align: center;">❌</div>
                <h2 style="color: #ec1313; text-align: center; margin-bottom: 12px; font-size: 20px;">Backend Analysis Failed</h2>
                <p style="color: #e0e0e0; text-align: center; font-size: 14px; line-height: 1.6;">
                    The backend service could not analyze this content.<br>
                    <strong style="color: #ec1313;">Error:</strong> ${analysisData.errorMessage || 'Unknown error'}
                </p>
                <div style="margin-top: 20px; padding: 15px; background: #1a0a0a; border-radius: 6px;">
                    <p style="color: #888; font-size: 13px; margin-bottom: 10px;"><strong>Possible reasons:</strong></p>
                    <ul style="color: #888; font-size: 12px; line-height: 1.8; padding-left: 20px;">
                        <li>Backend service is temporarily unavailable</li>
                        <li>Network connection issues</li>
                        <li>Content format not supported</li>
                    </ul>
                </div>
            </div>
        `;
    }

    // Quick stats bar - minimal
    const textLength = analysisData.collected_data_summary?.text_length || 0;
    const wordCount = analysisData.collected_data_summary?.word_count || 0;
    const flaggedCount = analysisData.flaggedCount || 0;
    
    html += `
        <div style="display: flex; justify-content: space-around; background: #2a2a2a; padding: 10px; border-radius: 6px; margin-bottom: 20px; font-size: 11px;">
            <div style="text-align: center;">
                <div style="color: #888;">Text Analyzed</div>
                <div style="font-weight: 600; color: #2563eb;">${wordCount} words</div>
            </div>
            <div style="text-align: center;">
                <div style="color: #888;">Content Type</div>
                <div style="font-weight: 600; color: #e0e0e0;">${analysisData.collected_data_summary?.content_type || 'Webpage'}</div>
            </div>
            <div style="text-align: center;">
                <div style="color: #888;">Analysis Time</div>
                <div style="font-weight: 600; color: #e0e0e0; font-size: 10px;">${scannedAt}</div>
            </div>
        </div>
    `;

    // Main analysis summary
    if (analysisData.analysis) {
        html += `
            <h2 style="margin-top: 25px; font-size: 18px; color: #e0e0e0;">Analysis Summary</h2>
            <div class="real-info" style="background: #2a2a2a; padding: 15px; border-radius: 8px;">
                <p style="line-height: 1.6; font-size: 14px; color: #e0e0e0; margin: 0;">${analysisData.analysis}</p>
            </div>
        `;
    }

    // Flagged sections - only show if we have real data and actual flags
    if (analysisData.flagged_sections && analysisData.flagged_sections.length > 0 && analysisData.flaggedCount > 0) {
        html += `
            <h2 style="margin-top: 25px; font-size: 18px; color: #e0e0e0;">⚠️ Flagged Content</h2>
            <div class="flagged-reasons">
                ${analysisData.flagged_sections.map((section, index) => `
                    <div style="margin-bottom: 15px; padding: 15px; background: #2a1a1a; border-radius: 8px; border-left: 4px solid #ec1313; border: 1px solid #ec1313;">
                        <div style="display: flex; align-items: center; margin-bottom: 10px;">
                            <div style="background: #ec1313; color: white; width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: bold; margin-right: 10px;">
                                ${index + 1}
                            </div>
                            <div style="font-weight: 600; color: #ec1313; font-size: 14px;">
                                ${section.reason}
                            </div>
                            <div style="margin-left: auto; color: #888; font-size: 11px;">
                                ${(section.confidence * 100).toFixed(0)}% confidence
                            </div>
                        </div>
                        <div style="color: #e0e0e0; font-size: 13px; line-height: 1.5; background: #1a0a0a; padding: 10px; border-radius: 4px; font-style: italic;">
                            "${section.text}"
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    }

    // Recommendations
    if (analysisData.recommendations && analysisData.recommendations.length > 0) {
        html += `
            <h2 style="margin-top: 25px; font-size: 18px; color: #e0e0e0;">💡 Recommendations</h2>
            <div class="real-info" style="background: #1a2a2a; padding: 15px; border-radius: 8px; border: 1px solid #2563eb;">
                ${analysisData.recommendations.map(rec => `
                    <div style="padding: 8px 0; padding-left: 20px; position: relative; font-size: 14px; color: #e0e0e0;">
                        <span style="position: absolute; left: 0; color: #2563eb; font-weight: bold; font-size: 16px;">•</span>
                        ${rec}
                    </div>
                `).join('')}
            </div>
        `;
    }

    // (Removed: Backend Data and Payload Sent to Backend sections - testing artifacts)

    analysisContent.innerHTML = html;
    
    // Hide the original data section
    document.getElementById('dataSection').style.display = 'none';
}

// NEW FUNCTION: Display backend analysis details
function showBackendAnalysis(analysisData) {
    if (!analysisData.backend_raw_result) {
        return '';
    }
    
    const backend = analysisData.backend_raw_result;

    let html = '';
    
    // AI Analysis Results - Prominent section
    const misinfoCount = backend.misinfo_indices?.length || 0;
    const verifiedCount = backend.rightinfo_indices?.length || 0;
    const totalClaims = misinfoCount + verifiedCount;
    
    // Handle both string and number confidence scores from backend
    let confidenceScore = 0.5;
    if (backend.confidence_score !== undefined) {
        if (typeof backend.confidence_score === 'string') {
            confidenceScore = parseFloat(backend.confidence_score);
        } else {
            confidenceScore = backend.confidence_score;
        }
        if (isNaN(confidenceScore) || confidenceScore < 0 || confidenceScore > 1) {
            confidenceScore = 0.5;
        }
    }
    const confidencePercent = (confidenceScore * 100).toFixed(0);
    
    html += `
        <div style="background: #1a2a2a; padding: 20px; border-radius: 10px; border: 2px solid #2563eb; margin-bottom: 20px;">
            <h2 style="color: #2563eb; margin-bottom: 20px; font-size: 20px; text-align: center;"> AI Analysis Results</h2>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 15px; margin-bottom: 20px;">
    `;

    // Show VERIFIED claims FIRST (green card)
    if (verifiedCount > 0) {
        html += `
                <div style="text-align: center; background: #2a2a2a; padding: 15px; border-radius: 8px; border: 2px solid #10b981;">
                    <div style="font-size: 12px; color: #888; margin-bottom: 8px;">✅ Verified Claims</div>
                    <div style="font-size: 32px; font-weight: 700; color: #10b981;">${verifiedCount}</div>
                </div>
        `;
    }
    
    // Show confidence and misinfo claims
    html += `
                <div style="text-align: center; background: #2a2a2a; padding: 15px; border-radius: 8px; border: 1px solid #f59e0b;">
                    <div style="font-size: 12px; color: #888; margin-bottom: 8px;">Confidence Score</div>
                    <div style="font-size: 24px; font-weight: 700; color: #f59e0b;">${confidencePercent}%</div>
                </div>
    `;
    
    // Show misinfo claims
    if (misinfoCount > 0) {
        html += `
                <div style="text-align: center; background: #2a2a2a; padding: 15px; border-radius: 8px; border: 1px solid #ec1313;">
                    <div style="font-size: 12px; color: #888; margin-bottom: 8px;"> Misinfo Claims</div>
                    <div style="font-size: 24px; font-weight: 700; color: #ec1313;">${misinfoCount}</div>
                </div>
        `;
    }
    
    // Show total analyzed
    if (totalClaims > 0) {
        html += `
                <div style="text-align: center; background: #2a2a2a; padding: 15px; border-radius: 8px; border: 1px solid #2563eb;">
                    <div style="font-size: 12px; color: #888; margin-bottom: 8px;">Total Claims</div>
                    <div style="font-size: 24px; font-weight: 700; color: #2563eb;">${totalClaims}</div>
                </div>
        `;
    }
    
    // Handle both Correctness (capital C) and correctness (lowercase)
    const isCorrect = backend.Correctness !== undefined ? backend.Correctness : backend.correctness;
    const isOutOfDomain = backend.Out_of_domain !== undefined ? backend.Out_of_domain : backend.out_of_domain;
    
    html += `
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; font-size: 13px;">
                <div style="text-align: center;">
                    <div style="color: #888; margin-bottom: 4px;">Out of Domain</div>
                    <div style="font-weight: 600; color: ${isOutOfDomain ? '#ec1313' : '#10b981'}">${isOutOfDomain ? 'Yes' : 'No'}</div>
                </div>
                <div style="text-align: center;">
                    <div style="color: #888; margin-bottom: 4px;">Analysis Correct</div>
                    <div style="font-weight: 600; color: ${isCorrect ? '#10b981' : '#ec1313'}">${isCorrect ? 'Yes' : 'No'}</div>
                </div>
            </div>
    `;

    // Show verification sources from backend if available
    console.log('🔍 Checking for sources:', backend.sources);
    // Normalize sources so backend can return either an array or a single string message
    const sourcesNormalized = (() => {
        const s = backend.sources;
        if (!s) return [];
        if (Array.isArray(s)) return s;
        if (typeof s === 'string') return [s];
        try { return Array.from(s); } catch (e) { return []; }
    })();

    if (sourcesNormalized.length > 0) {
        console.log(`✅ Found ${sourcesNormalized.length} sources to display`);
        html += `
            <div style="margin-top: 20px;">
                <div style="font-size: 18px; color: #10b981; font-weight: 600; margin-bottom: 12px; display: flex; align-items: center;">
                    <span style="margin-right: 8px; font-size: 24px;">🔍</span>
                    Verification Sources (${sourcesNormalized.length})
                </div>
                <div style="max-height: 300px; overflow-y: auto; background: #2a2a2a; padding: 15px; border-radius: 8px; border: 1px solid #10b981; box-shadow: 0 4px 15px rgba(16, 185, 129, 0.2);">
                    ${sourcesNormalized.map((source, index) => `
                        <div style="padding: 12px; border-bottom: ${index < sourcesNormalized.length - 1 ? '1px solid #333' : 'none'}; 
                                    background: rgba(16, 185, 129, 0.05); 
                                    border-radius: 4px; 
                                    margin-bottom: ${index < sourcesNormalized.length - 1 ? '8px' : '0'}; 
                                    transition: background 0.2s;"
                             onmouseover="this.style.background='rgba(16, 185, 129, 0.1)'" 
                             onmouseout="this.style.background='rgba(16, 185, 129, 0.05)'>
                            <div style="color: #10b981; font-size: 13px; word-break: break-all; display: block; font-weight: 500;">
                                ${source}
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    } else {
        console.log('❌ No sources found in backend response');
    }
    
    html += `</div>`;
    
    return html;
}

// Debug helper
window.debugStorage = function() {
    chrome.storage.local.get(null, function(data) {
        console.log('🔍 FULL STORAGE:', data);
        console.table(Object.keys(data).map(key => ({
            Key: key,
            Type: typeof data[key],
            HasValue: !!data[key]
        })));
    });
};

console.log('💡 Debug available: debugStorage()');