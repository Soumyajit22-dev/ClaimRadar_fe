this file has information about the backend--
POST
/api/v1/files/process_text
the backend take input here in this format
{
  "raw_texts": [
    "The WHO announced that polio has been eradicated worldwide as of 2025.",
    "Apple confirmed that all iPhones now include a built-in mind-reading chip to monitor users’ emotions.",
    "According to the UN, global hunger rates decreased slightly in 2024 due to international food aid programs.",
    "A viral post claims that climate change is caused by Earth’s shifting magnetic field, not greenhouse gases.",
    "The World Bank reported that India’s GDP grew by over 6% in 2024, maintaining strong post-pandemic recovery.",
    "A TikTok video suggests that placing garlic in your ear can cure ear infections instantly.",
    "NASA confirmed that human missions to Mars are expected to begin by the late 2030s.",
    "A Facebook post claims drinking hot water every morning prevents all viral infections — which is not scientifically supported.",
    "Reuters reported that AI-driven stock trading has surpassed human-led trading volumes in major global markets.",
    "A conspiracy blog claims that the moon landing was filmed on a Hollywood set and that NASA admitted it.",
    "The IMF stated that inflation in emerging economies began stabilizing by late 2024.",
    "A popular forum claims that vaccines alter human DNA permanently — which has no scientific backing.",
    "BBC News confirmed that renewable energy accounted for nearly 50% of global electricity production in 2024.",
    "An online rumor suggests that the Great Wall of China is visible from the Moon with the naked eye.",
    "According to WHO, antibiotic resistance remains one of the top ten global health threats.",
    "Some social media accounts claim 5G towers can read people’s thoughts, which is false.",
    "The UN announced new global carbon reduction goals during the 2025 Climate Summit in Geneva.",
    "NASA stated that the James Webb Space Telescope detected possible water vapor on an exoplanet similar to Earth.",
    "A tweet claims that global warming stopped in 2010, contradicting all scientific consensus.",
    "CNN reported that major world airlines plan to achieve net-zero carbon emissions by 2050."
  ],
  "resources": [
    "https://www.who.int",
    "https://www.un.org",
    "https://www.nasa.gov",
    "https://www.reuters.com",
    "https://www.bbc.com",
    "https://www.cnn.com",
    "https://www.imf.org",
    "https://www.worldbank.org"
  ]
}
-- we get output like this from the backend.

    "Correctness": true,
    "Out_of_domain": false,
    "misinfo_indices": [
        0,
        2,
        4
    ],
    "rightinfo_indices": [
        1,
        3,
        5,
        6,
        7,
        8,
        9,
        10,
        11,
        12,
        13,
        14,
        15,
        16,
        17,
        18,
        19
    ],
    "confidence_score": "0.85",
    "sources": [
        "https://www.who.int/news-room/fact-sheets/detail/poliomyelitis (General WHO polio info - no eradication announcement for 2025)",
        "https://www.who.int/news/item/29-04-2019-ten-threats-to-global-health-in-2019 (Antibiotic resistance as top global threat)",
        "https://mars.nasa.gov/mars-exploration/missions/future-missions/ (Mars mission plans not starting in 2030s)",
        "https://jwst.nasa.gov/content/science/exoplanets.html (JWST detection of water vapor on exoplanets)",
        "https://www.reuters.com/technology/ai-driven-stock-trading-hits-record-volumes-2024 (AI stock trading surpassing humans)",
        "https://www.worldbank.org/en/news/press-release/2024/india-economic-outlook (India GDP growth)",
        "https://www.imf.org/en/News/Articles/2024/12/15/late-2024-inflation-trends-emerging-markets (Inflation stabilization in emerging economies)",
        "https://www.un.org/en/climatechange/conference/2025 (UN carbon reduction goals)",
        "https://www.bbc.com/news/science-environment-2024-renewables (50% renewables in global electricity)",
        "https://edition.cnn.com/2024/12/01/environment/major-airlines-net-zero-2050/index.html (Airlines net-zero 2050)",
        "https://www.un.org/en/global-hunger-report-2024 (Global hunger rates decrease)",
        "https://www.climate.gov/news-features/understanding-climate/climate-change-myths-debunked (Climate change magnetic field myth debunked)",
        "https://www.healthline.com/health/ear-infection-myths (Garlic ear infection cure myth)",
        "https://www.cdc.gov/flu/prevent/hot-water-drinking.html (Hot water does not prevent viral infections)",
        "https://www.nasa.gov/feature/moon-landing-missions (Moon landing conspiracy false)",
        "https://www.fcc.gov/5g-myths (5G mind reading claims false)",
        "https://www.nasa.gov/5-things-to-know-about-the-great-wall-of-china-from-space (Great Wall visible from Moon myth false)",
        "https://www.who.int/news-room/q-a-detail/vaccines-and-dna (Vaccines do not alter DNA)",
        "https://climate.nasa.gov/faq/17/ (Global warming stopped in 2010 claim false)"
    ]