// details.js - Complete fixed version

document.addEventListener('DOMContentLoaded', function() {
    console.log('📄 Details page loaded');
    
    // Back button
    document.getElementById('backButton').addEventListener('click', function() {
        window.close();
    });

    // Refresh button
    document.getElementById('refreshButton').addEventListener('click', function() {
        location.reload();
    });

    // Load data immediately
    loadAnalysisData();
});

function loadAnalysisData() {
    console.log('🔍 Loading analysis data...');
    
    chrome.storage.local.get(['collectedData', 'currentAnalysis'], function(data) {
        console.log('📦 Retrieved from storage:', {
            hasCollectedData: !!data.collectedData,
            hasCurrentAnalysis: !!data.currentAnalysis
        });
        
        if (data.collectedData || data.currentAnalysis) {
            // Show data sections
            document.getElementById('noDataMessage').style.display = 'none';
            document.getElementById('dataSection').style.display = 'block';
            document.getElementById('analysisContent').style.display = 'block';
            
            // Display collected data
            showCollectedData(data.collectedData);
            
            // Display analysis results
            showAnalysisResults(data.currentAnalysis, data.collectedData);
            
        } else {
            // No data found
            console.log('❌ No data found in storage');
            document.getElementById('noDataMessage').style.display = 'block';
            document.getElementById('dataSection').style.display = 'none';
            document.getElementById('analysisContent').style.display = 'none';
        }
    });
}

function showCollectedData(collectedData) {
    console.log('📊 Displaying collected data');
    
    const dataContent = document.getElementById('dataContent');
    
    if (!collectedData) {
        dataContent.innerHTML = '<p style="color: #888; text-align: center;">No data collected</p>';
        return;
    }

    // Extract values safely
    const textLength = collectedData.content?.text?.length || 0;
    const wordCount = collectedData.content?.text ? 
        collectedData.content.text.split(/\s+/).length : 0;
    const contentType = (collectedData.content?.content_type || 'unknown').toUpperCase();
    const domain = collectedData.context?.domain || 'Unknown';

    // Data cards
    const statsHtml = `
        <div class="data-grid">
            <div class="data-card">
                <div class="data-value">${textLength.toLocaleString()}</div>
                <div class="data-label">CHARACTERS</div>
            </div>
            <div class="data-card">
                <div class="data-value">${wordCount.toLocaleString()}</div>
                <div class="data-label">WORDS</div>
            </div>
            <div class="data-card">
                <div class="data-value" style="font-size: 18px;">${contentType}</div>
                <div class="data-label">CONTENT TYPE</div>
            </div>
            <div class="data-card">
                <div class="data-value" style="font-size: 14px; word-break: break-all;">${domain}</div>
                <div class="data-label">DOMAIN</div>
            </div>
        </div>
    `;

    // JSON viewer
    const jsonViewer = `
        <details style="margin-top: 20px;">
            <summary style="cursor: pointer; color: #2563eb; font-weight: 600; padding: 10px; background: #2a2a2a; border-radius: 6px; user-select: none;">
                📋 View Raw JSON Data (Click to expand)
            </summary>
            <div class="json-viewer">
                <pre>${JSON.stringify(collectedData, null, 2)}</pre>
            </div>
        </details>
    `;

    dataContent.innerHTML = statsHtml + jsonViewer;
}

function showAnalysisResults(analysisData, collectedData) {
    console.log('🔍 Displaying analysis results');
    
    const analysisContent = document.getElementById('analysisContent');
    
    if (!analysisData) {
        analysisContent.innerHTML = `
            <div class="real-info">
                <p style="color: #888;">⚠️ No analysis results available yet.</p>
                <p style="color: #888; margin-top: 10px;">The page data has been collected. Analysis will appear here once processing is complete.</p>
            </div>
        `;
        return;
    }

    let html = '';

    // Source info
    const url = analysisData.url || collectedData?.content?.url || 'Unknown URL';
    const title = analysisData.title || collectedData?.content?.title || 'Untitled Page';
    const scannedAt = analysisData.scannedAt ? 
        new Date(analysisData.scannedAt).toLocaleString() : 'Recently';
    
    html += `
        <div class="source-info">
            <div class="source-label">Analyzed Page</div>
            <div style="color: #2563eb; font-size: 16px; margin-top: 5px; font-weight: 600;">${title}</div>
            <div style="color: #888; font-size: 12px; margin-top: 8px; word-break: break-all;">${url}</div>
            <div style="color: #666; font-size: 11px; margin-top: 8px;">Scanned: ${scannedAt}</div>
        </div>
    `;

    // Status badge and confidence
    const isMisleading = analysisData.is_misleading;
    const confidence = analysisData.confidence_score;
    const confidencePercent = confidence ? (confidence * 100).toFixed(0) : 'N/A';
    const statusColor = isMisleading ? '#ec1313' : '#10b981';
    const statusText = isMisleading ? '⚠️ Potentially Misleading' : '✓ Appears Credible';

    if (confidence) {
        html += `
            <div class="confidence-meter" style="background: ${isMisleading ? '#2a1a1a' : '#1a2a1a'};">
                <div class="confidence-label">Analysis Confidence:</div>
                <div class="confidence-value" style="color: ${statusColor};">${confidencePercent}%</div>
            </div>
        `;
    }

    html += `
        <div class="verification-badges">
            <div class="badge" style="background: ${isMisleading ? '#2a1a1a' : '#1a2a1a'}; border-color: ${statusColor}; color: ${statusColor};">
                ${statusText}
            </div>
            <div class="badge">AI Analysis</div>
            <div class="badge">Pattern Detection</div>
            ${analysisData.flaggedCount ? `<div class="badge">${analysisData.flaggedCount} Flags</div>` : ''}
        </div>
    `;

    // Main analysis
    html += `<h2>Analysis Summary</h2>`;
    
    if (analysisData.analysis) {
        html += `
            <div class="real-info">
                <p><strong style="color: ${statusColor};">${isMisleading ? '⚠️ Warning:' : '✓ Assessment:'}</strong></p>
                <p style="margin-top: 10px;">${analysisData.analysis}</p>
            </div>
        `;
    }

    // Flagged sections
    if (analysisData.flagged_sections && analysisData.flagged_sections.length > 0) {
        html += `
            <h2 style="margin-top: 30px;">Flagged Content Sections</h2>
            <div class="flagged-reasons">
                ${analysisData.flagged_sections.map(section => `
                    <div style="margin-bottom: 20px; padding: 15px; background: #2a1a1a; border-radius: 6px; border-left: 3px solid #ec1313;">
                        <div style="font-weight: 600; color: #ec1313; margin-bottom: 8px;">
                            ${section.reason} 
                            <span style="color: #888; font-size: 12px;">(${(section.confidence * 100).toFixed(0)}% confidence)</span>
                        </div>
                        <div style="color: #aaa; font-size: 13px; font-style: italic; line-height: 1.5;">
                            "${section.text}"
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    }

    // Recommendations
    if (analysisData.recommendations && analysisData.recommendations.length > 0) {
        html += `
            <h2 style="margin-top: 30px;">Recommendations</h2>
            <div class="real-info">
                ${analysisData.recommendations.map(rec => `
                    <div style="padding: 10px 0; padding-left: 25px; position: relative;">
                        <span style="position: absolute; left: 0; color: #2563eb; font-weight: bold;">→</span>
                        ${rec}
                    </div>
                `).join('')}
            </div>
        `;
    }

    // Data summary
    if (analysisData.collected_data_summary) {
        const summary = analysisData.collected_data_summary;
        html += `
            <div class="divider"></div>
            <h2>Analysis Metadata</h2>
            <div class="real-info">
                <div style="display: grid; grid-template-columns: auto 1fr; gap: 10px 20px;">
                    <strong>Text Analyzed:</strong>
                    <span>${summary.text_length?.toLocaleString() || 'N/A'} characters (${summary.word_count?.toLocaleString() || 'N/A'} words)</span>
                    
                    <strong>Content Type:</strong>
                    <span>${summary.content_type || 'Unknown'}</span>
                    
                    <strong>Domain:</strong>
                    <span>${summary.domain || 'Unknown'}</span>
                    
                    <strong>Analysis Time:</strong>
                    <span>${scannedAt}</span>
                </div>
            </div>
        `;
    }

    analysisContent.innerHTML = html;
}

// Debug helper
window.debugStorage = function() {
    chrome.storage.local.get(null, function(data) {
        console.log('🔍 FULL STORAGE:', data);
        console.table(Object.keys(data).map(key => ({
            Key: key,
            Type: typeof data[key],
            HasValue: !!data[key]
        })));
    });
};

console.log('💡 Debug available: debugStorage()');