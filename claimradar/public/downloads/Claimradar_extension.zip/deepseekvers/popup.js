// popup.js - Updated version with real backend integration

document.addEventListener('DOMContentLoaded', function() {
    const scanButton = document.getElementById('scanButton');
    const viewFlaggedContent = document.getElementById('viewFlaggedContent');
    const settingsButton = document.getElementById('settingsButton');
    const currentSiteElement = document.getElementById('current-site');
    const flagCountElement = document.getElementById('flagCount');
    const flagSubtitleElement = document.getElementById('flagSubtitle');
    let isScanning = false;
    // Toggle this to true to force a unique payload per request (debug only)
    const DEBUG_FORCE_NONCE = true;

    // Reset UI to default state when popup opens
    resetUI();
    updateCurrentSiteInfo();
    checkForExistingData();

    // Scan Button - Direct approach with REAL backend
    scanButton.addEventListener('click', async function() {
        if (isScanning) return;
        isScanning = true;
        const originalText = scanButton.textContent;

        // Ensure complete cache clear before starting
        scanButton.textContent = 'Clearing cache...';
        await clearAnalysisCache();

        scanButton.textContent = 'Scanning...';
        scanButton.classList.add('btn-loading');
        scanButton.disabled = true;

        // Reset to scanning state
        flagCountElement.textContent = '...';
        flagCountElement.style.fontSize = '36px';
        flagCountElement.style.color = '#ff6b6b';
        flagSubtitleElement.textContent = 'Analyzing with AI...';
        flagSubtitleElement.style.color = 'rgba(255, 255, 255, 0.7)';
        flagSubtitleElement.style.textAlign = 'center';

        try {
            // Get current tab
            const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
            
            if (!tab) {
                throw new Error('No active tab found');
            }

            // Inject script to extract page data
            const pageData = await extractPageData(tab.id);
            
            // Get user settings for sensitivity
            const settings = await new Promise(resolve => {
                chrome.storage.local.get(['sensitivity'], resolve);
            });
            
            // Perform REAL backend analysis
            const analysis = await performRealBackendAnalysis(pageData, settings.sensitivity);
            
            // Store everything
            await storeData(pageData, analysis);
            
            // Check if there was an error
            if (analysis.error) {
                // Show error UI
                flagCountElement.innerHTML = '❌';
                flagCountElement.style.fontSize = '42px';
                flagCountElement.style.color = '#ec1313';
                flagSubtitleElement.innerHTML = `Backend Error<br><small style="color: #888; font-size: 12px;">${analysis.errorMessage}</small>`;
                flagSubtitleElement.style.color = '#ec1313';
                flagSubtitleElement.style.textAlign = 'center';
                scanButton.textContent = 'Retry';
                showNotification('Backend analysis failed: ' + analysis.errorMessage, 'error');
            } else {
                // Update UI with analysis results
                updateUIWithAnalysisResults(analysis);
                
                // Show success
                showNotification('AI analysis complete!');
            }
            
        } catch (error) {
            console.error('Scan failed:', error);
            scanButton.textContent = '❌ Failed';
            // Reset to default state on failure
            resetUI();
            showNotification('Scan failed: ' + error.message, 'error');
        } finally {
            setTimeout(() => {
                scanButton.textContent = 'Rescan';
                scanButton.classList.remove('btn-loading');
                scanButton.disabled = false;
                isScanning = false;
            }, 2000);
        }
    });

    // NEW FUNCTION: Reset UI to default state
    function resetUI() {
        flagCountElement.textContent = '0';
        flagCountElement.style.fontSize = '36px';
        flagCountElement.style.color = '#ff6b6b';
        flagSubtitleElement.textContent = 'Click scan to analyze this page';
        flagSubtitleElement.style.color = 'rgba(255, 255, 255, 0.7)';
        flagSubtitleElement.style.textAlign = 'center';
        flagSubtitleElement.style.lineHeight = '1.4';
        
        // Reset scan button
        scanButton.textContent = 'Scan';
        scanButton.classList.remove('btn-loading');
        scanButton.disabled = false;
        
        // Reset view button
        updateViewFlaggedButton(false);
    }

    // NEW FUNCTION: Update UI with analysis results including verified symbols
    function updateUIWithAnalysisResults(analysis) {
        const confidencePercent = (analysis.confidence_score !== undefined && analysis.confidence_score !== null)
            ? (parseFloat(analysis.confidence_score) * 100).toFixed(0)
            : 'N/A';
        
        if (analysis.is_misleading) {
            // Content is potentially misleading
            flagCountElement.innerHTML = '⚠️';
            flagCountElement.style.fontSize = '42px';
            flagCountElement.style.color = '#ec1313';
            flagSubtitleElement.innerHTML = `Potentially Misleading<br><small style="color: #888; font-size: 12px;">${confidencePercent}% confidence</small>`;
            flagSubtitleElement.style.color = '#ec1313';
            flagSubtitleElement.style.textAlign = 'center';
            flagSubtitleElement.style.lineHeight = '1.4';
        } else {
            // Content appears credible
            flagCountElement.innerHTML = '✅';
            flagCountElement.style.fontSize = '42px';
            flagCountElement.style.color = '#10b981';
            flagSubtitleElement.innerHTML = `AI Verified<br><small style="color: #888; font-size: 12px;">${confidencePercent}% confidence</small>`;
            flagSubtitleElement.style.color = '#10b981';
            flagSubtitleElement.style.textAlign = 'center';
            flagSubtitleElement.style.lineHeight = '1.4';
        }
        
        // Update the scan button to show completion
        scanButton.textContent = '✅ Scanned';
        updateViewFlaggedButton(true);
    }

    // View Flagged Content Button
    viewFlaggedContent.addEventListener('click', function() {
        chrome.storage.local.get(['collectedData'], function(data) {
            if (data.collectedData) {
                chrome.tabs.create({
                    url: chrome.runtime.getURL('details.html')
                });
            } else {
                viewFlaggedContent.textContent = 'Please Scan First';
                viewFlaggedContent.style.backgroundColor = '#f59e0b';
                
                setTimeout(() => {
                    viewFlaggedContent.textContent = 'View Flagged Content';
                    viewFlaggedContent.style.backgroundColor = '#2563eb';
                }, 2000);
            }
        });
    });

    // Settings Button
    settingsButton.addEventListener('click', function() {
        chrome.tabs.create({url: 'settings.html'});
    });

    // Extract page data directly
    async function extractPageData(tabId) {
        const results = await chrome.scripting.executeScript({
            target: { tabId: tabId },
            func: extractPageContent
        });
        
        return results[0].result;
    }

    // Function to run in the page context
    function extractPageContent() {
        // Simple data extraction
        const pageData = {
            url: window.location.href,
            title: document.title,
            domain: window.location.hostname,
            mainText: document.body.innerText.substring(0, 5000), // Limit text
            timestamp: new Date().toISOString(),
            contentType: 'webpage'
        };

        // Try to extract meta data
        const metadata = {};
        const metaTags = document.querySelectorAll('meta');
        metaTags.forEach(tag => {
            const name = tag.getAttribute('name') || tag.getAttribute('property');
            const content = tag.getAttribute('content');
            if (name && content) {
                metadata[name] = content;
            }
        });

        pageData.metadata = metadata;
        return pageData;
    }

    // REAL Backend Analysis Function
    async function performRealBackendAnalysis(pageData, sensitivity = 'medium') {
        console.log('🚀 Starting real backend analysis...');
        
        try {
            // Map sensitivity settings to backend values
            const sensitivityMap = {
                'low': 0,
                'medium': 1, 
                'high': 2
            };
            
            const backendSensitivity = sensitivityMap[sensitivity] || 1;

            // Prepare text for analysis
            const analysisText = pageData.mainText || '';
            const textChunks = splitTextIntoChunks(analysisText);

            if (textChunks.length === 0) {
                throw new Error('No text content to analyze');
            }

            console.log(`📨 Sending ${textChunks.length} text chunks to backend...`);

            // Call backend API
            const backendResponse = await callBackendAPI(textChunks, backendSensitivity);
            
            // Transform backend response to frontend format and include the exact payload/sensitivity used
            return transformBackendResponse(backendResponse.backendResult, textChunks, pageData, backendResponse.payloadSent, backendResponse.sensitivitySent);

        } catch (error) {
            console.error('❌ Backend analysis failed:', error);
            // Return error object instead of falling back silently
            return {
                error: true,
                errorMessage: error.message,
                is_misleading: false,
                confidence_score: 0,
                analysis: "Backend analysis failed. Please try again later or check your internet connection.",
                flaggedCount: 0,
                verifiedCount: 0,
                flagged_sections: [],
                recommendations: [
                    "Check your internet connection",
                    "Try scanning again",
                    "If problem persists, the backend service may be unavailable"
                ],
                collected_data_summary: {
                    text_length: pageData.mainText?.length || 0,
                    word_count: pageData.mainText ? pageData.mainText.split(/\s+/).length : 0,
                    content_type: pageData.contentType || 'unknown',
                    domain: pageData.domain || 'unknown'
                },
                backend_raw_result: null,
                url: pageData.url || 'Unknown URL',
                title: pageData.title || 'Untitled Page',
                scannedAt: new Date().toISOString()
            };
        }
    }

    // Split text into chunks for analysis
    function splitTextIntoChunks(text, maxChunkSize = 1000) {
        if (!text || text.length === 0) return [];
        
        const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
        const chunks = [];
        let currentChunk = '';

        sentences.forEach(sentence => {
            const sentenceWithPunctuation = sentence.trim() + '. ';
            if ((currentChunk + sentenceWithPunctuation).length > maxChunkSize && currentChunk.length > 0) {
                chunks.push(currentChunk.trim());
                currentChunk = sentenceWithPunctuation;
            } else {
                currentChunk += sentenceWithPunctuation;
            }
        });

        if (currentChunk.length > 0) {
            chunks.push(currentChunk.trim());
        }

        return chunks.slice(0, 10); // Limit to 10 chunks max
    }

    // Call the backend API
    async function callBackendAPI(textChunks, sensitivity) {
        // Resources should be the same trusted sources for every analysis (from readme.txt)
        const payload = {
            raw_texts: textChunks,
            resources: [
                "https://www.who.int",
                "https://www.un.org",
                "https://www.nasa.gov",
                "https://www.reuters.com",
                "https://www.bbc.com",
                "https://www.cnn.com",
                "https://www.imf.org",
                "https://www.worldbank.org"
            ]
        };

        // Attach a debug nonce to force server to treat this as a fresh request
        if (DEBUG_FORCE_NONCE) {
            payload.debug_nonce = new Date().toISOString() + '-' + Math.random().toString(36).slice(2,8);
        }

    // Log the EXACT payload being sent
    console.log('📤 EXACT BACKEND PAYLOAD:', JSON.stringify(payload, null, 2));
    // Request URL will include input_id when DEBUG_FORCE_NONCE is enabled
    console.log('📤 Request URL (base):', `https://claimradar.onrender.com/api/v1/files/process_text?sensitivity=${sensitivity}`);

        // Build request URL; include input_id when forcing nonce so server treats it as unique
        const inputIdParam = DEBUG_FORCE_NONCE && payload.debug_nonce ? `&input_id=${encodeURIComponent(payload.debug_nonce)}` : '';
        const requestUrl = `https://claimradar.onrender.com/api/v1/files/process_text?sensitivity=${sensitivity}${inputIdParam}`;

        console.log('📤 Final Request URL:', requestUrl);

        const response = await fetch(
            requestUrl,
            {
                method: 'POST',
                cache: 'no-store', // force fetch bypassing any browser caches
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'Cache-Control': 'no-cache, no-store, must-revalidate',
                    'Pragma': 'no-cache',
                    // Add a header nonce too in case the server keys caching on headers
                    ...(DEBUG_FORCE_NONCE ? { 'X-Debug-Nonce': payload.debug_nonce } : {})
                },
                body: JSON.stringify(payload)
            }
        );

        if (!response.ok) {
            throw new Error(`API error: ${response.status}`);
        }

        // Capture raw text and headers so we can compare extension vs Postman
        const responseStatus = response.status;
        const responseHeaders = {};
        try {
            response.headers.forEach((value, key) => { responseHeaders[key] = value; });
        } catch (e) {
            // older browsers may not support forEach on headers
            for (const pair of response.headers.entries?.() || []) {
                responseHeaders[pair[0]] = pair[1];
            }
        }

        const responseText = await response.text();
        let result;
        try {
            result = JSON.parse(responseText);
        } catch (e) {
            result = responseText;
        }
        console.log('📥 Backend response received:', result, { status: responseStatus, headers: responseHeaders });

        // Build audit entry to help debug mismatches between Postman and extension calls
        const auditEntry = {
            timestamp: new Date().toISOString(),
            requestUrl,
            payloadSent: payload,
            responseReceived: result,
            responseStatus,
            responseHeaders,
            responseText
        };

        // Append audit entry to chrome.storage.local.analysisHistory (keep a short rolling log)
        try {
            chrome.storage.local.get(['analysisHistory'], function(data) {
                const history = Array.isArray(data.analysisHistory) ? data.analysisHistory : [];
                history.push(auditEntry);
                // Keep only the last 20 entries to avoid unbounded growth
                const limited = history.slice(-20);
                chrome.storage.local.set({ analysisHistory: limited }, function() {
                    console.log('🗄️ Analysis audit saved (most recent):', auditEntry);
                });
            });
        } catch (e) {
            console.warn('⚠️ Failed to save audit entry:', e);
        }

        // Return both the backend result and the exact payload we sent (plus sensitivity) so callers can persist/display it
        return {
            backendResult: result,
            payloadSent: payload,
            sensitivitySent: sensitivity
        };
    }

    // Transform backend response to frontend format
    function transformBackendResponse(backendResult, textChunks, pageData, payloadSent = null, sensitivitySent = null) {
        console.log('🔄 Transforming backend response...', backendResult);
        
        const misinfoCount = backendResult.misinfo_indices?.length || 0;
        const verifiedCount = backendResult.rightinfo_indices?.length || 0;
        const isMisleading = misinfoCount > 0;
        
        // Handle confidence_score carefully - it comes as string or number
        let confidence = 0.5;
        if (backendResult.confidence_score !== undefined) {
            if (typeof backendResult.confidence_score === 'string') {
                confidence = parseFloat(backendResult.confidence_score);
            } else {
                confidence = backendResult.confidence_score;
            }
            
            // Ensure it's a valid number between 0 and 1
            if (isNaN(confidence) || confidence < 0 || confidence > 1) {
                console.warn('Invalid confidence_score from backend:', backendResult.confidence_score);
                confidence = 0.5;
            }
        }
        
        console.log('📊 Transformed data:', {
            misinfoCount,
            verifiedCount,
            isMisleading,
            confidence,
            hasSources: !!backendResult.sources
        });
        
        // Build flagged sections from misinformation indices
        const flaggedSections = (backendResult.misinfo_indices || []).map(index => {
            const text = textChunks[index] || 'Content not available';
            return {
                text: text.length > 200 ? text.substring(0, 200) + '...' : text,
                reason: "AI-detected potential misinformation",
                confidence: confidence
            };
        });

        return {
            is_misleading: isMisleading,
            confidence_score: confidence,
            analysis: generateAnalysisText(backendResult, misinfoCount, verifiedCount, confidence),
            flaggedCount: misinfoCount,
            verifiedCount: verifiedCount,
            flagged_sections: flaggedSections,
            collected_data_summary: {
                text_length: pageData.mainText?.length || 0,
                word_count: pageData.mainText ? pageData.mainText.split(/\s+/).length : 0,
                content_type: pageData.contentType || 'unknown',
                domain: pageData.domain || 'unknown',
                chunks_analyzed: textChunks.length,
                misinformation_found: misinfoCount,
                verified_claims: verifiedCount
            },
            recommendations: generateRecommendations(backendResult),
            backend_raw_result: backendResult, // Keep original for debugging
            backend_payload_sent: payloadSent || null,
            backend_sensitivity: sensitivitySent || null,
            url: pageData.url || 'Unknown URL',
            title: pageData.title || 'Untitled Page',
            scannedAt: new Date().toISOString()
        };
    }

    function generateAnalysisText(backendResult, misinfoCount, verifiedCount, confidence) {
        if (misinfoCount === 0 && verifiedCount > 0) {
            return "No significant misinformation detected. The content appears generally credible with several verified claims.";
        } else if (misinfoCount === 0) {
            return "No significant misinformation detected. The content appears generally credible, though always verify critical claims with multiple sources.";
        }
        
        const confidenceText = confidence > 0.8 ? 'high confidence' : confidence > 0.6 ? 'moderate confidence' : 'low confidence';
        
        return `This content contains ${misinfoCount} potential misinformation claim${misinfoCount > 1 ? 's' : ''} detected with ${confidenceText}. Cross-reference these claims with trusted fact-checking sources.`;
    }

    function generateRecommendations(backendResult) {
        const baseRecommendations = [
            "Verify claims with multiple independent sources",
            "Check the publication date and author credentials",
            "Look for corroborating evidence from reputable organizations"
        ];

        if (backendResult.misinfo_indices && backendResult.misinfo_indices.length > 0) {
            baseRecommendations.unshift("Review the flagged sections carefully before sharing");
            
            if (backendResult.sources && backendResult.sources.length > 0) {
                baseRecommendations.push("Consult the provided verification sources for fact-checking");
            }
        }

        return baseRecommendations;
    }

    // Keep the original mock analysis as fallback
    function generateMockAnalysis(pageData) {
        const isMisleading = Math.random() > 0.5;
        const confidenceScore = (Math.random() * 0.3 + 0.6).toFixed(2);
        
        return {
            is_misleading: isMisleading,
            confidence_score: parseFloat(confidenceScore),
            analysis: isMisleading 
                ? "This content shows patterns commonly associated with misinformation."
                : "This content appears credible based on initial analysis.",
            flaggedCount: isMisleading ? 12 : 3,
            verifiedCount: isMisleading ? 2 : 8,
            recommendations: [
                "Verify with trusted sources",
                "Check publication date",
                "Look for multiple perspectives"
            ],
            collected_data_summary: {
                text_length: pageData.mainText.length,
                word_count: pageData.mainText.split(/\s+/).length,
                content_type: pageData.contentType,
                domain: pageData.domain
            }
        };
    }

    
    // Clear all analysis related data from storage
    async function clearAnalysisCache() {
        const keysToRemove = [
            'collectedData',
            'currentAnalysis',
            'lastAnalysisUrl',
            'lastScanTime',
            'flaggedCount',
            'analysisHistory'
        ];
        
        await new Promise((resolve) => {
            chrome.storage.local.remove(keysToRemove, () => {
                console.log('🗑️ Cache cleared:', keysToRemove);
                resolve();
            });
        });
    }

    // Store data
    async function storeData(pageData, analysis) {
        // Deep-clone analysis to ensure no references/prototypes remain that could be mutated later
        const analysisClone = JSON.parse(JSON.stringify(analysis || {}));

        const dataToStore = {
            collectedData: {
                content: {
                    text: pageData.mainText,
                    title: pageData.title,
                    url: pageData.url,
                    content_type: pageData.contentType
                },
                context: {
                    domain: pageData.domain,
                    metadata: pageData.metadata
                }
            },
            currentAnalysis: analysisClone,
            collectionTime: new Date().toISOString(),
            lastAnalysisUrl: pageData.url,
            lastScanTime: Date.now(),
            flaggedCount: analysis.flaggedCount
        };

        await new Promise((resolve) => {
            chrome.storage.local.set(dataToStore, () => {
                console.log('💾 New data stored, cache refreshed');
                resolve();
            });
        });
    }

    // Show notification
    function showNotification(message, type = 'info') {
        // Simple notification - you could make this fancier
        console.log('🔔', message);
        
        // Optional: Create a small notification in the popup
        const notification = document.createElement('div');
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            top: 10px;
            right: 10px;
            background: ${type === 'error' ? '#ec1313' : '#2563eb'};
            color: white;
            padding: 8px 12px;
            border-radius: 4px;
            font-size: 12px;
            z-index: 1000;
        `;
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }

    function updateCurrentSiteInfo() {
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            if (tabs[0]) {
                const domain = getDomain(tabs[0].url);
                currentSiteElement.textContent = `Scan ${domain}`;
            }
        });
    }

    function checkForExistingData() {
        chrome.storage.local.get(['collectedData', 'currentAnalysis', 'lastAnalysisUrl'], function(data) {
            // Check if we have analysis data AND it's for the current URL
            chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
                if (tabs[0] && data.lastAnalysisUrl === tabs[0].url && data.currentAnalysis) {
                    // Only show previous analysis if it's for the same URL
                    updateUIWithAnalysisResults(data.currentAnalysis);
                } else {
                    // Reset to default state if no relevant analysis data
                    resetUI();
                }
            });
        });
    }

    function updateViewFlaggedButton(hasData) {
        if (hasData) {
            viewFlaggedContent.textContent = 'View Flagged Content';
            viewFlaggedContent.style.backgroundColor = '#2563eb';
        } else {
            viewFlaggedContent.textContent = 'Please Scan First';
            viewFlaggedContent.style.backgroundColor = '#f59e0b';
        }
    }

    function getDomain(url) {
        try {
            const domain = new URL(url).hostname;
            return domain.replace('www.', '');
        } catch (e) {
            return 'this page';
        }
    }
});