// api.js - Service to communicate with your backend
class ClaimRadarAPI {
    constructor() {
        this.baseURL = 'https://claimradar.onrender.com';
    }

    async analyzeContent(texts, sensitivity = 1) {
        try {
            console.log('🔍 Sending data to backend for analysis...');
            
            const payload = {
                raw_texts: Array.isArray(texts) ? texts : [texts],
                resources: [] // We'll add the current URL
            };

            const response = await fetch(
                `${this.baseURL}/api/v1/files/process_text?sensitivity=${sensitivity}`,
                {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(payload)
                }
            );

            if (!response.ok) {
                throw new Error(`API error: ${response.status}`);
            }

            const result = await response.json();
            console.log('✅ Backend analysis received:', result);
            return result;

        } catch (error) {
            console.error('❌ API call failed:', error);
            throw error;
        }
    }

    // Helper to split large text into chunks for analysis
    splitTextIntoChunks(text, maxChunkSize = 1000) {
        const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
        const chunks = [];
        let currentChunk = '';

        sentences.forEach(sentence => {
            if ((currentChunk + sentence).length > maxChunkSize && currentChunk.length > 0) {
                chunks.push(currentChunk.trim());
                currentChunk = sentence;
            } else {
                currentChunk += sentence + '. ';
            }
        });

        if (currentChunk.length > 0) {
            chunks.push(currentChunk.trim());
        }

        return chunks;
    }
}

// Create global instance
window.claimRadarAPI = new ClaimRadarAPI();