// Background script for the TruthLens extension

// Set first run flag and redirect to login
chrome.runtime.onInstalled.addListener(function(details) {
  if (details.reason === 'install') {
    // Extension first installed, open login page
    chrome.tabs.create({
      url: chrome.runtime.getURL('login.html')
    });
  }
  
  // Set default settings
  chrome.storage.local.set({
    misinformationFlagging: true,
    sensitivity: 'medium',
    trustedSources: ['example.com', 'another-example.org'],
    untrustedSources: ['fakenews.net'],
    flaggedCount: 0,
    loggedIn: false
  });
});

// Listen for tab updates to potentially scan new pages
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
  if (changeInfo.status === 'complete') {
    // Content script will handle the scanning
  }
});
// b----ackground.js - Simple version
chrome.runtime.onInstalled.addListener(function() {
  chrome.storage.local.set({
    misinformationFlagging: true,
    sensitivity: 'medium',
    flaggedCount: 0
  });
});

// NEW: Handle messages from content script to open details page
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === "openDetailsPage") {
    console.log('🔄 Opening details page from background script...');
    chrome.tabs.create({
      url: chrome.runtime.getURL('details.html')
    });
    sendResponse({success: true});
  }
  return true;
});