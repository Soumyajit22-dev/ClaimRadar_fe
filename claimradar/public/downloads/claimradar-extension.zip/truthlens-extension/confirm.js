document.getElementById('openDashboard').addEventListener('click', function() {
    // Close the current tab
    window.close();
});

// Set extension as active
document.addEventListener('DOMContentLoaded', function() {
    chrome.storage.local.set({ 
        setupComplete: true,
        active: true 
    });
});