// settings.js - Fixed functionality with sensitivity slider

document.addEventListener('DOMContentLoaded', function() {
    // Load saved settings
    loadSettings();
    
    // Initialize toggle functionality
    initToggle();
    
    // Initialize sensitivity slider
    initSensitivitySlider();
    
    // Initialize source management
    initSourceManagement();
    
    // Initialize save button
    initSaveButton();
    
    // Initialize issue reporting
    initIssueReporting();
});

function loadSettings() {
    chrome.storage.local.get([
        'misinformationFlagging',
        'sensitivity',
        'trustedSources',
        'untrustedSources'
    ], function(data) {
        // Set toggle state
        const toggle = document.getElementById('flaggingToggle');
        if (toggle) {
            if (data.misinformationFlagging !== false) {
                toggle.classList.add('active');
            } else {
                toggle.classList.remove('active');
            }
        }
        
        // Set sensitivity slider
        const slider = document.getElementById('sensitivitySlider');
        const valueDisplay = document.getElementById('sensitivityValue');
        if (slider && valueDisplay) {
            let sensitivityValue = data.sensitivity || 'medium';
            let sliderValue = 2; // Default to medium
            
            if (sensitivityValue === 'low') sliderValue = 1;
            else if (sensitivityValue === 'medium') sliderValue = 2;
            else if (sensitivityValue === 'high') sliderValue = 3;
            
            slider.value = sliderValue;
            updateSensitivityDisplay(sliderValue, valueDisplay);
        }
        
        // Populate trusted sources
        if (data.trustedSources && data.trustedSources.length > 0) {
            const trustedList = document.getElementById('trustedList');
            trustedList.innerHTML = '';
            data.trustedSources.forEach(source => {
                addSourceToList(trustedList, source);
            });
        }
        
        // Populate untrusted sources
        if (data.untrustedSources && data.untrustedSources.length > 0) {
            const untrustedList = document.getElementById('untrustedList');
            untrustedList.innerHTML = '';
            data.untrustedSources.forEach(source => {
                addSourceToList(untrustedList, source);
            });
        }
    });
}

function initToggle() {
    const toggle = document.getElementById('flaggingToggle');
    if (toggle) {
        toggle.addEventListener('click', function() {
            this.classList.toggle('active');
        });
    }
}

function initSensitivitySlider() {
    const slider = document.getElementById('sensitivitySlider');
    const valueDisplay = document.getElementById('sensitivityValue');
    
    if (slider && valueDisplay) {
        slider.addEventListener('input', function() {
            updateSensitivityDisplay(this.value, valueDisplay);
        });
    }
}

function updateSensitivityDisplay(value, displayElement) {
    const sensitivityMap = {
        1: { text: 'Low', color: '#10b981' },
        2: { text: 'Medium', color: '#f59e0b' },
        3: { text: 'High', color: '#ec1313' }
    };
    
    const sensitivity = sensitivityMap[value];
    if (sensitivity) {
        displayElement.textContent = sensitivity.text;
        displayElement.style.color = sensitivity.color;
    }
}

function initSourceManagement() {
    // Add trusted sources
    const trustedAddButton = document.getElementById('addTrusted');
    const trustedInput = document.getElementById('trustedInput');
    
    if (trustedAddButton && trustedInput) {
        trustedAddButton.addEventListener('click', function() {
            addSource(trustedInput, 'trustedList');
        });
        
        // Allow Enter key to add source
        trustedInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                addSource(trustedInput, 'trustedList');
            }
        });
    }
    
    // Add untrusted sources
    const untrustedAddButton = document.getElementById('addUntrusted');
    const untrustedInput = document.getElementById('untrustedInput');
    
    if (untrustedAddButton && untrustedInput) {
        untrustedAddButton.addEventListener('click', function() {
            addSource(untrustedInput, 'untrustedList');
        });
        
        // Allow Enter key to add source
        untrustedInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                addSource(untrustedInput, 'untrustedList');
            }
        });
    }
    
    // Initialize delete buttons for existing sources
    document.querySelectorAll('.delete-button').forEach(button => {
        button.addEventListener('click', function() {
            this.closest('.source-item').remove();
        });
    });
}

function addSource(inputElement, listId) {
    const source = inputElement.value.trim();
    if (source && isValidURL(source)) {
        const list = document.getElementById(listId);
        addSourceToList(list, source);
        inputElement.value = '';
    } else {
        alert('Please enter a valid website URL (e.g., example.com)');
    }
}

function addSourceToList(list, source) {
    const listItem = document.createElement('li');
    listItem.className = 'source-item';
    listItem.innerHTML = `
        <span>${source}</span>
        <button class="delete-button">×</button>
    `;
    
    // Add delete functionality
    listItem.querySelector('.delete-button').addEventListener('click', function() {
        listItem.remove();
    });
    
    list.appendChild(listItem);
}

function isValidURL(string) {
    // Simple URL validation - just check if it looks like a domain
    return string.length > 0 && !string.includes(' ') && 
           (string.includes('.') || string.includes('localhost'));
}

function initSaveButton() {
    const saveButton = document.getElementById('saveButton');
    if (saveButton) {
        saveButton.addEventListener('click', function() {
            // Collect all settings
            const sliderValue = document.getElementById('sensitivitySlider').value;
            const sensitivityMap = {
                1: 'low',
                2: 'medium', 
                3: 'high'
            };
            
            const settings = {
                misinformationFlagging: document.getElementById('flaggingToggle').classList.contains('active'),
                sensitivity: sensitivityMap[sliderValue] || 'medium',
                trustedSources: getSources('trustedList'),
                untrustedSources: getSources('untrustedList')
            };
            
            // Save to storage
            chrome.storage.local.set(settings, function() {
                console.log('Settings saved:', settings);
                
                // Redirect to confirmation page
                window.location.href = 'confirm.html';
            });
        });
    }
}

function getSources(listId) {
    const list = document.getElementById(listId);
    const items = list.querySelectorAll('.source-item span');
    return Array.from(items).map(item => item.textContent);
}

function initIssueReporting() {
    const cancelButton = document.getElementById('cancelIssue');
    const submitButton = document.getElementById('submitIssue');
    const issueTextarea = document.getElementById('issueText');
    
    if (cancelButton) {
        cancelButton.addEventListener('click', function() {
            issueTextarea.value = '';
        });
    }
    
    if (submitButton) {
        submitButton.addEventListener('click', function() {
            const issue = issueTextarea.value.trim();
            if (issue) {
                // In a real app, this would send to a backend
                alert('Thank you for your feedback! We\'ll review this issue.');
                issueTextarea.value = '';
                
                // Save issue report locally
                chrome.storage.local.get(['reportedIssues'], function(data) {
                    const issues = data.reportedIssues || [];
                    issues.push({
                        text: issue,
                        timestamp: new Date().toISOString()
                    });
                    chrome.storage.local.set({ reportedIssues: issues });
                });
            } else {
                alert('Please describe the issue before submitting.');
            }
        });
    }
}