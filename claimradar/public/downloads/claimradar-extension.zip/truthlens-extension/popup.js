// popup.js - Simple version that does everything

document.addEventListener('DOMContentLoaded', function() {
    const scanButton = document.getElementById('scanButton');
    const viewFlaggedContent = document.getElementById('viewFlaggedContent');
    const settingsButton = document.getElementById('settingsButton');
    const currentSiteElement = document.getElementById('current-site');
    const flagCountElement = document.getElementById('flagCount');
    const flagSubtitleElement = document.getElementById('flagSubtitle');

    updateCurrentSiteInfo();
    checkForExistingData();

    // Scan Button - Direct approach
    scanButton.addEventListener('click', async function() {
        const originalText = scanButton.textContent;
        
        scanButton.textContent = 'Scanning...';
        scanButton.classList.add('btn-loading');
        scanButton.disabled = true;

        flagCountElement.textContent = '...';
        flagSubtitleElement.textContent = 'Analyzing page content...';

        try {
            // Get current tab
            const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
            
            if (!tab) {
                throw new Error('No active tab found');
            }

            // Inject script to extract page data
            const pageData = await extractPageData(tab.id);
            
            // Generate mock analysis
            const analysis = generateMockAnalysis(pageData);
            
            // Store everything
            await storeData(pageData, analysis);
            
            // Update UI
            scanButton.textContent = '✅ Scanned';
            flagSubtitleElement.textContent = 'Analysis complete';
            updateFlagCount();
            updateViewFlaggedButton(true);
            
            // Show success
            showNotification('Page scanned successfully!');
            
        } catch (error) {
            console.error('Scan failed:', error);
            scanButton.textContent = '❌ Failed';
            flagSubtitleElement.textContent = 'Scan failed - try again';
        } finally {
            setTimeout(() => {
                scanButton.textContent = 'Rescan';
                scanButton.classList.remove('btn-loading');
                scanButton.disabled = false;
            }, 2000);
        }
    });

    // View Flagged Content Button
    viewFlaggedContent.addEventListener('click', function() {
        chrome.storage.local.get(['collectedData'], function(data) {
            if (data.collectedData) {
                chrome.tabs.create({
                    url: chrome.runtime.getURL('details.html')
                });
            } else {
                viewFlaggedContent.textContent = 'Please Scan First';
                viewFlaggedContent.style.backgroundColor = '#f59e0b';
                
                setTimeout(() => {
                    viewFlaggedContent.textContent = 'View Flagged Content';
                    viewFlaggedContent.style.backgroundColor = '#2563eb';
                }, 2000);
            }
        });
    });

    // Settings Button
    settingsButton.addEventListener('click', function() {
        chrome.tabs.create({url: 'settings.html'});
    });

    // Extract page data directly
    async function extractPageData(tabId) {
        const results = await chrome.scripting.executeScript({
            target: { tabId: tabId },
            func: extractPageContent
        });
        
        return results[0].result;
    }

    // Function to run in the page context
    function extractPageContent() {
        // Simple data extraction
        const pageData = {
            url: window.location.href,
            title: document.title,
            domain: window.location.hostname,
            mainText: document.body.innerText.substring(0, 5000), // Limit text
            timestamp: new Date().toISOString(),
            contentType: 'webpage'
        };

        // Try to extract meta data
        const metadata = {};
        const metaTags = document.querySelectorAll('meta');
        metaTags.forEach(tag => {
            const name = tag.getAttribute('name') || tag.getAttribute('property');
            const content = tag.getAttribute('content');
            if (name && content) {
                metadata[name] = content;
            }
        });

        pageData.metadata = metadata;
        return pageData;
    }

    // Generate mock analysis
    function generateMockAnalysis(pageData) {
        const isMisleading = Math.random() > 0.5;
        const confidenceScore = (Math.random() * 0.3 + 0.6).toFixed(2);
        
        return {
            is_misleading: isMisleading,
            confidence_score: parseFloat(confidenceScore),
            analysis: isMisleading 
                ? "This content shows patterns commonly associated with misinformation."
                : "This content appears credible based on initial analysis.",
            flaggedCount: isMisleading ? 12 : 3,
            recommendations: [
                "Verify with trusted sources",
                "Check publication date",
                "Look for multiple perspectives"
            ],
            collected_data_summary: {
                text_length: pageData.mainText.length,
                word_count: pageData.mainText.split(/\s+/).length,
                content_type: pageData.contentType,
                domain: pageData.domain
            }
        };
    }

    // Store data
    async function storeData(pageData, analysis) {
        const dataToStore = {
            collectedData: {
                content: {
                    text: pageData.mainText,
                    title: pageData.title,
                    url: pageData.url,
                    content_type: pageData.contentType
                },
                context: {
                    domain: pageData.domain,
                    metadata: pageData.metadata
                }
            },
            currentAnalysis: analysis,
            collectionTime: new Date().toISOString(),
            lastAnalysisUrl: pageData.url,
            lastScanTime: Date.now(),
            flaggedCount: analysis.flaggedCount
        };

        await new Promise((resolve) => {
            chrome.storage.local.set(dataToStore, resolve);
        });
    }

    // Show notification
    function showNotification(message) {
        // Simple notification - you could make this fancier
        console.log('🔔', message);
    }

    function updateFlagCount() {
        chrome.storage.local.get(['flaggedCount'], function(data) {
            if (data.flaggedCount) {
                flagCountElement.textContent = data.flaggedCount;
                flagSubtitleElement.textContent = 'Potential misinformation claims';
            }
        });
    }

    function updateCurrentSiteInfo() {
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            if (tabs[0]) {
                const domain = getDomain(tabs[0].url);
                currentSiteElement.textContent = `Scan ${domain}`;
            }
        });
    }

    function checkForExistingData() {
        chrome.storage.local.get(['collectedData'], function(data) {
            if (data.collectedData) {
                updateViewFlaggedButton(true);
                updateFlagCount();
            }
        });
    }

    function updateViewFlaggedButton(hasData) {
        if (hasData) {
            viewFlaggedContent.textContent = 'View Flagged Content';
            viewFlaggedContent.style.backgroundColor = '#2563eb';
        } else {
            viewFlaggedContent.textContent = 'Please Scan First';
            viewFlaggedContent.style.backgroundColor = '#f59e0b';
        }
    }

    function getDomain(url) {
        try {
            const domain = new URL(url).hostname;
            return domain.replace('www.', '');
        } catch (e) {
            return 'this page';
        }
    }

    updateFlagCount();
});