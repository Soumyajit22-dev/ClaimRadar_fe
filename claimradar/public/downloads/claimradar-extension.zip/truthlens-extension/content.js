// Content script for highlighting potentially misleading content and data collection

// Store flagged elements
let flaggedElements = [];

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
  console.log('🚀 ClaimRadar content script initialized');
});

// Function to scan page for potentially misleading content
function scanPageForMisinformation() {
  clearFlags();
  
  const walker = document.createTreeWalker(
    document.body,
    NodeFilter.SHOW_TEXT,
    null,
    false
  );
  
  const textNodes = [];
  let node;
  while (node = walker.nextNode()) {
    if (node.textContent.trim().length > 20) {
      textNodes.push(node);
    }
  }
  
  const nodesToFlag = getRandomElements(textNodes, 2, 3);
  nodesToFlag.forEach(node => flagContent(node));
  
  chrome.storage.local.set({flaggedCount: flaggedElements.length});
}

// Function to flag a content node
function flagContent(textNode) {
  const parent = textNode.parentNode;
  
  if (parent.classList.contains('truthlens-flagged')) {
    return;
  }
  
  const wrapper = document.createElement('span');
  wrapper.className = 'truthlens-flagged relative';
  wrapper.style.backgroundColor = 'rgba(236, 19, 19, 0.1)';
  wrapper.style.borderLeft = '2px solid #ec1313';
  wrapper.style.paddingLeft = '4px';
  wrapper.style.marginLeft = '2px';
  
  const warningIcon = document.createElement('span');
  warningIcon.innerHTML = '⚠️';
  warningIcon.style.position = 'absolute';
  warningIcon.style.right = '-20px';
  warningIcon.style.top = '0';
  warningIcon.style.cursor = 'pointer';
  warningIcon.style.fontSize = '12px';
  
  const tooltip = document.createElement('div');
  tooltip.className = 'truthlens-tooltip';
  tooltip.innerHTML = 'Possible misleading claim — needs verification.';
  tooltip.style.position = 'absolute';
  tooltip.style.bottom = '100%';
  tooltip.style.left = '0';
  tooltip.style.backgroundColor = '#181111';
  tooltip.style.color= 'white';
  tooltip.style.padding = '5px 10px';
  tooltip.style.borderRadius = '4px';
  tooltip.style.fontSize = '12px';
  tooltip.style.whiteSpace = 'nowrap';
  tooltip.style.zIndex = '10000';
  tooltip.style.display = 'none';
  tooltip.style.boxShadow = '0 2px 5px rgba(0,0,0,0.2)';
  
  warningIcon.addEventListener('mouseenter', () => tooltip.style.display = 'block');
  warningIcon.addEventListener('mouseleave', () => tooltip.style.display = 'none');
  
  wrapper.appendChild(document.createTextNode(textNode.textContent));
  wrapper.appendChild(warningIcon);
  wrapper.appendChild(tooltip);
  parent.replaceChild(wrapper, textNode);
  
  flaggedElements.push(wrapper);
}

// Function to clear all flags
function clearFlags() {
  flaggedElements.forEach(element => {
    if (element.parentNode) {
      const textNode = document.createTextNode(element.textContent);
      element.parentNode.replaceChild(textNode, element);
    }
  });
  flaggedElements = [];
}

// Helper function to get random elements from array
function getRandomElements(array, min, max) {
  const count = Math.floor(Math.random() * (max - min + 1)) + min;
  const shuffled = array.sort(() => 0.5 - Math.random());
  return shuffled.slice(0, Math.min(count, array.length));
}

// ========== DATA COLLECTION FUNCTIONS ==========

function collectPageData() {
  console.log('🔍 ClaimRadar: Collecting page data...');
  
  const pageData = {
    url: window.location.href,
    title: document.title,
    domain: window.location.hostname,
    mainText: extractMainText(),
    metadata: extractMetadata(),
    timestamp: new Date().toISOString(),
    contentType: detectContentType(),
    textStructure: analyzeTextStructure()
  };
  
  console.log('📊 Collected page data:', {
    url: pageData.url,
    title: pageData.title,
    textLength: pageData.mainText.length,
    contentType: pageData.contentType
  });
  
  return pageData;
}

function extractMainText() {
  console.log('📝 Extracting main text content...');
  
  const contentSelectors = [
    'article', 'main', '[role="main"]',
    '[data-testid="tweet"]', '[data-testid="post"]',
    '.status', '.post', '.tweet',
    '.article', '.story', '.content',
    '.post-content', '.entry-content',
    '.main-content', '.page-content', '.body-content'
  ];
  
  let extractedText = '';
  
  for (const selector of contentSelectors) {
    const elements = document.querySelectorAll(selector);
    if (elements.length > 0) {
      console.log(`✅ Found content with selector: ${selector}`);
      
      elements.forEach(element => {
        const text = cleanText(element.textContent);
        if (text.length > 50) {
          extractedText += text + '\n\n';
        }
      });
      
      if (extractedText.length > 300) break;
    }
  }
  
  if (extractedText.length < 100) {
    console.log('⚠️ Using body as fallback');
    extractedText = cleanText(document.body.textContent);
  }
  
  return extractedText.substring(0, 15000);
}

function cleanText(text) {
  return text
    .replace(/\s+/g, ' ')
    .replace(/\n+/g, '\n')
    .replace(/[^\S\n]+/g, ' ')
    .trim();
}

function extractMetadata() {
  const metadata = {
    author: getMetaContent('author') || getMetaContent('twitter:creator'),
    description: getMetaContent('description') || getMetaContent('og:description'),
    publishedTime: getMetaContent('article:published_time'),
    keywords: getMetaContent('keywords'),
    siteName: getMetaContent('og:site_name')
  };
  
  Object.keys(metadata).forEach(key => {
    if (!metadata[key]) delete metadata[key];
  });
  
  return metadata;
}

function getMetaContent(name) {
  const selector = `meta[name="${name}"], meta[property="${name}"]`;
  const element = document.querySelector(selector);
  return element ? element.getAttribute('content') : null;
}

function detectContentType() {
  const domain = window.location.hostname;
  
  if (domain.includes('twitter.com') || domain.includes('x.com')) return 'social_media';
  if (domain.includes('facebook.com')) return 'social_media';
  if (domain.includes('youtube.com')) return 'video';
  if (domain.includes('reddit.com')) return 'social_media';
  if (document.querySelector('article') || document.querySelector('.article')) return 'article';
  if (document.querySelector('main') || document.querySelector('[role="main"]')) return 'blog';
  if (document.querySelector('[data-testid="tweet"]')) return 'social_media';
  return 'general';
}

function analyzeTextStructure() {
  return {
    hasHeadings: document.querySelector('h1, h2, h3, h4, h5, h6') !== null,
    hasLists: document.querySelector('ul, ol') !== null,
    hasQuotes: document.querySelector('blockquote, q') !== null,
    paragraphCount: document.querySelectorAll('p').length,
    headingCount: document.querySelectorAll('h1, h2, h3, h4, h5, h6').length,
    wordCount: document.body.textContent.split(/\s+/).length,
    linkCount: document.querySelectorAll('a').length
  };
}

// ========== FIXED: Enhanced formatDataForAPI with safety checks ==========
function formatDataForAPI(pageData, userSettings) {
  // Ensure pageData has all required fields
  const safePageData = {
    mainText: pageData?.mainText || '',
    title: pageData?.title || document.title || 'Untitled',
    url: pageData?.url || window.location.href,
    contentType: pageData?.contentType || 'unknown',
    domain: pageData?.domain || window.location.hostname,
    metadata: pageData?.metadata || {},
    textStructure: pageData?.textStructure || {},
    timestamp: pageData?.timestamp || new Date().toISOString()
  };

  return {
    content: {
      text: safePageData.mainText,
      title: safePageData.title,
      url: safePageData.url,
      content_type: safePageData.contentType
    },
    context: {
      domain: safePageData.domain,
      metadata: safePageData.metadata,
      structure: safePageData.textStructure
    },
    user_settings: {
      sensitivity: userSettings?.sensitivity || 'medium',
      trusted_sources: userSettings?.trustedSources || [],
      untrusted_sources: userSettings?.untrustedSources || []
    },
    request_info: {
      timestamp: safePageData.timestamp,
      version: '1.0',
      analysis_type: 'text_only',
      extension_id: chrome.runtime.id
    }
  };
}

function highlightPageForDemo() {
  const paragraphs = document.querySelectorAll('p');
  const toHighlight = Math.min(3, paragraphs.length);
  
  for (let i = 0; i < toHighlight; i++) {
    if (paragraphs[i].textContent.trim().length > 50) {
      paragraphs[i].style.backgroundColor = 'rgba(236, 19, 19, 0.1)';
      paragraphs[i].style.borderLeft = '2px solid #ec1313';
      paragraphs[i].style.paddingLeft = '8px';
      paragraphs[i].style.marginBottom = '4px';
    }
  }
}

function showNotification(message, type = 'info') {
  const notification = document.createElement('div');
  const bgColor = type === 'success' ? '#10b981' : type === 'error' ? '#ec1313' : '#2563eb';
  
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: ${bgColor};
    color: white;
    padding: 12px 16px;
    border-radius: 8px;
    z-index: 10000;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    font-size: 14px;
    font-weight: 500;
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    max-width: 300px;
  `;
  
  notification.textContent = message;
  document.body.appendChild(notification);
  
  setTimeout(() => notification.remove(), 4000);
}

// ========== MESSAGE LISTENER ==========

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  console.log('📨 Content script received message:', request.action);
  
  if (request.action === "getFlaggedCount") {
    sendResponse({count: flaggedElements.length});
    return false;
    
  } else if (request.action === "showFlaggedContent") {
    console.log('📄 Opening details page...');
    
    try {
      window.open(chrome.runtime.getURL('details.html'), '_blank');
      sendResponse({success: true});
    } catch (error) {
      console.error('❌ Error opening details:', error);
      sendResponse({success: false, error: error.message});
    }
    return false;
    
  } else if (request.action === "scanPage") {
    console.log('🚀 Starting comprehensive page scan...');
    showNotification('Scanning page content...', 'info');
    
    // Use setTimeout to ensure async operations complete
    setTimeout(() => performScan(sendResponse), 100);
    
    return true; // Keep channel open for async
  }
  
  return false;
});

// ========== FIXED: Enhanced performScan with better error handling ==========
function performScan(sendResponse) {
  try {
    console.log('🔄 Executing scan...');
    
    // Step 1: Visual highlighting
    try {
      scanPageForMisinformation();
      console.log('✅ Step 1: Visual scan complete');
    } catch (visualError) {
      console.warn('⚠️ Visual scan partial failure:', visualError.message);
      // Continue anyway - visual scan is not critical
    }
    
    // Step 2: Collect page data with fallback
    let pageData;
    try {
      pageData = collectPageData();
      console.log('✅ Step 2: Page data collected, text length:', pageData.mainText.length);
    } catch (collectionError) {
      console.warn('⚠️ Data collection partial failure, using minimal data');
      pageData = {
        url: window.location.href,
        title: document.title || 'Untitled',
        domain: window.location.hostname,
        mainText: document.body ? document.body.textContent.substring(0, 1000) : '',
        metadata: {},
        timestamp: new Date().toISOString(),
        contentType: 'unknown',
        textStructure: {}
      };
    }
    
    // Step 3: Get settings and process
    chrome.storage.local.get(['sensitivity', 'trustedSources', 'untrustedSources'], function(settings) {
      console.log('✅ Step 3: Settings retrieved:', settings);
      
      try {
        // Format data for API
        const apiData = formatDataForAPI(pageData, settings);
        console.log('✅ Step 4: API data formatted');
        
        // Generate analysis
        const mockAnalysis = generateCompleteMockAnalysis(apiData, pageData);
        console.log('✅ Step 5: Analysis generated:', {
          isMisleading: mockAnalysis.is_misleading,
          confidence: mockAnalysis.confidence_score,
          flaggedCount: mockAnalysis.flaggedCount
        });
        
        // Store everything
        const dataToStore = {
          collectedData: apiData,
          currentAnalysis: mockAnalysis,
          collectionTime: new Date().toISOString(),
          lastAnalysisUrl: window.location.href,
          lastScanTime: Date.now(),
          flaggedCount: mockAnalysis.flaggedCount
        };
        
        console.log('💾 Storing data to chrome.storage...');
        
        chrome.storage.local.set(dataToStore, function() {
          if (chrome.runtime.lastError) {
            console.error('❌ Storage error:', chrome.runtime.lastError);
            showNotification('Storage failed: ' + chrome.runtime.lastError.message, 'error');
            sendResponse({success: false, error: chrome.runtime.lastError.message});
            return;
          }
          
          console.log('✅ Step 6: Data stored successfully');
          
          // Verify storage
          chrome.storage.local.get(['collectedData', 'currentAnalysis', 'flaggedCount'], function(verify) {
            console.log('🔍 Verification:', {
              hasCollectedData: !!verify.collectedData,
              hasAnalysis: !!verify.currentAnalysis,
              flaggedCount: verify.flaggedCount
            });
          });
          
          // Visual feedback
          if (mockAnalysis.is_misleading) {
            try {
              highlightPageForDemo();
            } catch (highlightError) {
              console.warn('⚠️ Highlighting failed:', highlightError);
            }
          }
          
          // Success notification
          showNotification('✓ Scan complete! Click "View Flagged Content" for details.', 'success');
          
          console.log('✅ Scan completed successfully');
          sendResponse({success: true});
        });
        
      } catch (innerError) {
        console.error('❌ Error during data processing:', innerError);
        console.error('Stack:', innerError.stack);
        showNotification('Processing error: ' + innerError.message, 'error');
        sendResponse({success: false, error: innerError.message});
      }
    });
    
  } catch (error) {
    console.error('❌ Scan error:', error);
    console.error('Error stack:', error.stack);
    showNotification('Scan failed: ' + error.message, 'error');
    sendResponse({success: false, error: error.message});
  }
}

// ========== FIXED: Enhanced generateCompleteMockAnalysis with safety checks ==========
function generateCompleteMockAnalysis(apiData, pageData) {
  console.log('🔬 Generating mock analysis...');
  
  // SAFETY CHECK: Ensure apiData has required structure
  if (!apiData || !apiData.content) {
    console.error('❌ Invalid apiData structure:', apiData);
    throw new Error('Invalid data structure - apiData.content is missing');
  }
  
  const isMisleading = Math.random() > 0.5;
  const confidenceScore = parseFloat((Math.random() * 0.3 + 0.6).toFixed(2));
  const flaggedCount = isMisleading ? 
    Math.floor(Math.random() * 5) + 8 : 
    Math.floor(Math.random() * 3) + 1;
  
  // Safe text extraction with fallbacks
  const safeText = apiData.content?.text || '';
  const textLength = safeText.length;
  const wordCount = textLength > 0 ? safeText.split(/\s+/).length : 0;
  
  return {
    is_misleading: isMisleading,
    confidence_score: confidenceScore,
    analysis: isMisleading 
      ? "This content shows patterns commonly associated with misinformation. Multiple claims require fact-checking and verification from trusted sources."
      : "Initial analysis suggests this content is likely credible, though independent verification is always recommended.",
    flaggedCount: flaggedCount,
    flagged_sections: isMisleading && textLength > 500 ? [
      {
        text: safeText.substring(0, 200) + "...",
        reason: "Potential exaggeration or unsupported claim",
        confidence: 0.72
      },
      {
        text: safeText.substring(Math.min(300, textLength), Math.min(500, textLength)) + "...",
        reason: "Language patterns suggest emotional manipulation",
        confidence: 0.65
      }
    ] : [],
    collected_data_summary: {
      text_length: textLength,
      word_count: wordCount,
      content_type: apiData.content?.content_type || 'unknown',
      domain: apiData.context?.domain || 'unknown'
    },
    recommendations: isMisleading ? [
      "Cross-reference claims with trusted fact-checking websites",
      "Check the publication date and author credentials",
      "Look for corroborating evidence from multiple sources",
      "Be cautious of emotionally charged language"
    ] : [
      "Still verify critical information independently",
      "Check for any updates or corrections",
      "Consider multiple perspectives on the topic"
    ],
    url: pageData?.url || window.location.href,
    title: pageData?.title || document.title || 'Untitled',
    scannedAt: new Date().toISOString()
  };
}

// Debug functions
window.debugStorage = function() {
  chrome.storage.local.get(null, function(data) {
    console.log('🔍 FULL STORAGE DUMP:', data);
    console.table(Object.keys(data).map(key => ({
      key: key,
      type: typeof data[key],
      hasValue: !!data[key]
    })));
  });
};

window.testDetailsPage = function() {
  console.log('🧪 Testing details page opening...');
  window.open(chrome.runtime.getURL('details.html'), '_blank');
};

window.collectPageData = collectPageData;

// Initialize
setTimeout(() => {
  console.log('✅ ClaimRadar content script loaded successfully');
  console.log('💡 Debug commands: debugStorage(), testDetailsPage(), collectPageData()');
}, 1000);